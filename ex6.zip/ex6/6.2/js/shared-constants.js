// js/shared-constants.js
const margin = { top: 40, right: 30, bottom: 50, left: 70 };
const width = 800;
const height = 400;
const innerWidth = width - margin.left - margin.right;
const innerHeight = height - margin.top - margin.bottom;

let innerChartS; // for scatterplot only
const tooltipWidth = 65;
const tooltipHeight = 32;

const xScaleS = d3.scaleLinear();
const yScaleS = d3.scaleLinear();
const colorScale = d3.scaleOrdinal();

const barColor = "#664646";
const bodyBackgroundColor = "#fffaf0";
