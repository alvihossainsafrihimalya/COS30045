// js/scatterplot.js
const drawScatterplot = (data) => {
  const svg = d3.select("#scatterplot")
    .append("svg")
    .attr("viewBox", `0 0 ${width} ${height}`);

  innerChartS = svg.append("g")
    .attr("transform", `translate(${margin.left}, ${margin.top})`);

  // Set domains
  xScaleS.domain(d3.extent(data, d => d.star)).range([0, innerWidth]);
  yScaleS.domain(d3.extent(data, d => d.energyConsumption)).range([innerHeight, 0]);
  colorScale.domain(["LED", "LCD", "OLED"]).range(["#ff7f0e", "#1f77b4", "#2ca02c"]);

  // Draw circles
  innerChartS.selectAll("circle")
    .data(data)
    .enter()
    .append("circle")
    .attr("cx", d => xScaleS(d.star))
    .attr("cy", d => yScaleS(d.energyConsumption))
    .attr("r", 4)
    .attr("fill", d => colorScale(d.screenTech))
    .attr("opacity", 0.6);

  // Axes
  innerChartS.append("g")
    .attr("transform", `translate(0, ${innerHeight})`)
    .call(d3.axisBottom(xScaleS));

  innerChartS.append("g")
    .call(d3.axisLeft(yScaleS));
};
