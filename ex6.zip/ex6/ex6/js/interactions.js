// Function to populate filter buttons for histogram
const populateFilters = (data) => {
  const filtersDiv = d3.select("#filters_screen");
  filtersDiv.selectAll("button")
    .data(filters_screen)
    .enter()
    .append("button")
    .attr("class", d => d.isActive ? "active" : "")
    .text(d => d.label)
    .on("click", (event, d) => {
      // Update button states
      filters_screen.forEach(f => f.isActive = false);
      d.isActive = true;

      // Update button styles
      d3.selectAll("#filters_screen button")
        .attr("class", f => f.id === d.id ? "active" : "");

      // Update histogram
      updateHistogram(data, d.id);
    });
};

// Helper function to update histogram based on active filter
const updateHistogram = (data, activeId) => {
  const filteredData = activeId === "all"
    ? data
    : data.filter(d => d.screenTech === activeId);

  const updatedBins = binGenerator(filteredData);

  innerChart.selectAll("rect")
    .data(updatedBins)
    .join("rect")
    .transition()
    .duration(500)
    .attr("x", d => xScale(d.x0))
    .attr("y", d => yScale(d.length))
    .attr("width", d => xScale(d.x1) - xScale(d.x0) - 1)
    .attr("height", d => innerHeight - yScale(d.length))
    .attr("fill", barColor);
};

// Function to create tooltip for scatterplot
const createTooltip = () => {
  tooltip = innerChartS.append("g")
    .attr("class", "tooltip")
    .style("opacity", 0);

  tooltip.append("rect")
    .attr("width", tooltipWidth)
    .attr("height", tooltipHeight)
    .attr("rx", 6)
    .attr("fill", barColor)
    .style("opacity", 0.8);

  tooltip.append("text")
    .text("NA")
    .attr("x", tooltipWidth / 2)
    .attr("y", tooltipHeight / 2 + 2)
    .attr("text-anchor", "middle")
    .attr("alignment-baseline", "middle")
    .attr("fill", "white")
    .style("font-weight", 900);
};

// Mouse interaction for tooltips
const handleMouseEvents = () => {
  innerChartS.selectAll("circle")
    .on("mouseenter", (e, d) => {
      console.log("Mouse entered circle", d);

      d3.select(".tooltip text")
        .text(d.screenSize);

      const cx = e.target.getAttribute("cx");
      const cy = e.target.getAttribute("cy");

      d3.select(".tooltip")
        .attr("transform", `translate(${cx - 0.5 * tooltipWidth}, ${cy - 1.5 * tooltipHeight})`)
        .transition()
        .duration(200)
        .style("opacity", 1);
    })
    .on("mouseleave", () => {
      console.log("Mouse left circle");
      d3.select(".tooltip")
        .style("opacity", 0)
        .attr("transform", "translate(0, 500)");
    });
};
