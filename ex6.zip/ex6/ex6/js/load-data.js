// Load the CSV file with a row conversion function
d3.csv("data/Ex6_TVdata.csv", d => ({
  brand: d.brand,
  model: d.model,
  screenSize: +d.screenSize,
  screenTech: d.screenTech,
  energyConsumption: +d.energyConsumption,
  star: +d.star
})).then(data => {
  console.log("CSV Loaded:", data);

  // Call all necessary visualisation functions
  drawHistogram(data);         // From histogram.js (6.1)
  drawScatterplot(data);       // From scatterplot.js (6.2)
  populateFilters(data);       // Shared filter buttons
  createTooltip();             // Tooltip setup
  handleMouseEvents();         // Tooltip interactivity
}).catch(error => {
  console.error("Error loading the CSV file:", error);
});
