// Dimensions and margins
const margin = { top: 40, right: 30, bottom: 50, left: 70 };
const width = 800;
const height = 400;
const innerWidth = width - margin.left - margin.right;
const innerHeight = height - margin.top - margin.bottom;

// Tooltip size
const tooltipWidth = 65;
const tooltipHeight = 32;

// Scales (for scatterplot and histogram)
let innerChartS;  // For scatterplot specifically
const xScale = d3.scaleLinear();
const yScale = d3.scaleLinear();
const xScaleS = d3.scaleLinear(); // For scatterplot
const yScaleS = d3.scaleLinear();
const colorScale = d3.scaleOrdinal()
  .domain(["LED", "LCD", "OLED"])
  .range(["#ff7f0e", "#1f77b4", "#2ca02c"]);
  
  // Bin generator for histogram (used in drawHistogram)
const binGenerator = d3.bin()
  .value(d => d.energyConsumption)
  .thresholds(20);


// Color variables
const barColor = "#66464f";
const bodyBackgroundColor = "#fffaf0";

// Filter toggle buttons
const filters_screen = [
  { id: "all", label: "All", isActive: true },
  { id: "LED", label: "LED", isActive: false },
  { id: "LCD", label: "LCD", isActive: false },
  { id: "OLED", label: "OLED", isActive: false }
];
