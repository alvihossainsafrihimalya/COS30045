// Margins and size
const margin = { top: 40, right: 30, bottom: 50, left: 70 };
const width = 800, height = 400;
const innerWidth = width - margin.left - margin.right;
const innerHeight = height - margin.top - margin.bottom;

// Bin generator
const binGenerator = d3.bin()
  .value(d => d.energyConsumption)
  .thresholds(20);

// Filter options
const filters_screen = [
  { id: "All", label: "All", isActive: true },
  { id: "LED", label: "LED", isActive: false },
  { id: "LCD", label: "LCD", isActive: false },
  { id: "OLED", label: "OLED", isActive: false }
];
