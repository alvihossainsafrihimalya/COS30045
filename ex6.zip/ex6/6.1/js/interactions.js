const populateFilters = (data) => {
  const container = d3.select("#filters_screen");

  container.selectAll("button")
    .data(filters_screen)
    .join("button")
    .text(d => d.label)
    .attr("class", d => d.isActive ? "active" : "")
    .on("click", (event, d) => {
      filters_screen.forEach(f => f.isActive = (f.id === d.id));
      container.selectAll("button")
        .attr("class", btn => btn.isActive ? "active" : "");

      let filtered = (d.id === "All") ? data : data.filter(tv => tv.screenTech === d.id);
      updateHistogram(filtered);
    });
};

const updateHistogram = (filteredData) => {
  const bins = binGenerator(filteredData);
  const yScale = d3.scaleLinear()
    .domain([0, d3.max(bins, d => d.length)])
    .range([innerHeight, 0]);

  const svg = d3.select("svg");
  const innerChart = svg.select("g");

  const xScale = d3.scaleLinear()
    .domain([0, d3.max(bins, d => d.x1)])
    .range([0, innerWidth]);

  // Update bars
  const bars = innerChart.selectAll("rect")
    .data(bins);

  bars.join(
    enter => enter.append("rect")
      .attr("x", d => xScale(d.x0))
      .attr("width", d => xScale(d.x1) - xScale(d.x0) - 1)
      .attr("y", innerHeight)
      .attr("height", 0)
      .attr("fill", "#5a3e2b")
      .transition().duration(500)
      .attr("y", d => yScale(d.length))
      .attr("height", d => innerHeight - yScale(d.length)),

    update => update
      .transition().duration(500)
      .attr("y", d => yScale(d.length))
      .attr("height", d => innerHeight - yScale(d.length)),

    exit => exit.remove()
  );
};
