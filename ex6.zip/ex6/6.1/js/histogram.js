const drawHistogram = (data) => {
  const svg = d3.select("#histogram")
    .append("svg")
    .attr("viewBox", `0 0 ${width} ${height}`);

  const innerChart = svg.append("g")
    .attr("transform", `translate(${margin.left}, ${margin.top})`);

  const bins = binGenerator(data);

  const xScale = d3.scaleLinear()
    .domain([0, d3.max(bins, d => d.x1)])
    .range([0, innerWidth]);

  const yScale = d3.scaleLinear()
    .domain([0, d3.max(bins, d => d.length)])
    .range([innerHeight, 0]);

  innerChart.selectAll("rect")
    .data(bins)
    .join("rect")
    .attr("x", d => xScale(d.x0))
    .attr("width", d => xScale(d.x1) - xScale(d.x0) - 1)
    .attr("y", d => yScale(d.length))
    .attr("height", d => innerHeight - yScale(d.length))
    .attr("fill", "#5a3e2b");

  innerChart.append("g")
    .attr("transform", `translate(0, ${innerHeight})`)
    .call(d3.axisBottom(xScale));

  innerChart.append("g")
    .call(d3.axisLeft(yScale));
};
