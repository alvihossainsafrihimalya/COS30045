d3.csv("data/Ex6_TVdata.csv", d => ({
  brand: d.brand,
  model: d.model,
  screenSize: +d.screenSize,
  screenTech: d.screenTech,
  energyConsumption: +d.energyConsumption,
  star: +d.star
}))
.then(data => {
  drawHistogram(data);
  populateFilters(data);
})
.catch(err => console.error("❌ Error loading CSV:", err));
