d3.csv("data/cleandata.csv").then(data => {
  data.forEach(d => {
    d["Avg_mode_power"] = +d["Avg_mode_power"];
    d["Star Rating Index"] = +d["Star Rating Index"];
  });

  const width = 500, height = 400;
  const svg = d3.select("#scatter").append("svg").attr("viewBox", `0 0 ${width} ${height}`);

  const x = d3.scaleLinear()
    .domain(d3.extent(data, d => d["Star Rating Index"]))
    .range([40, width - 20]);

  const y = d3.scaleLinear()
    .domain(d3.extent(data, d => d["Avg_mode_power"]))
    .range([height - 40, 20]);

  svg.append("g")
    .attr("transform", `translate(0,${height-40})`)
    .call(d3.axisBottom(x));

  svg.append("g")
    .attr("transform", `translate(40,0)`)
    .call(d3.axisLeft(y));

  svg.selectAll("circle")
    .data(data)
    .join("circle")
      .attr("cx", d => x(d["Star Rating Index"]))
      .attr("cy", d => y(d["Avg_mode_power"]))
      .attr("r", 3)
      .attr("fill", "teal");
});
