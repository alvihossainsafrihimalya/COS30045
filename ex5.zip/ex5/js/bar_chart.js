d3.csv("data/cleandata.csv").then(data => {
  const grouped = d3.rollup(
    data,
    v => d3.mean(v, d => +d["Avg_mode_power"]),
    d => d["Screen_Tech"]
  );

  const processed = Array.from(grouped, ([Screen_Tech, AvgPower]) => ({ Screen_Tech, AvgPower }));

  const width = 500, height = 400;
  const svg = d3.select("#bar").append("svg").attr("viewBox", `0 0 ${width} ${height}`);

  const x = d3.scaleBand()
    .domain(processed.map(d => d.Screen_Tech))
    .range([40, width - 20])
    .padding(0.2);

  const y = d3.scaleLinear()
    .domain([0, d3.max(processed, d => d.AvgPower)])
    .range([height - 40, 20]);

  svg.append("g")
    .attr("transform", `translate(0,${height-40})`)
    .call(d3.axisBottom(x));

  svg.append("g")
    .attr("transform", `translate(40,0)`)
    .call(d3.axisLeft(y));

  svg.selectAll("rect")
    .data(processed)
    .join("rect")
      .attr("x", d => x(d.Screen_Tech))
      .attr("y", d => y(d.AvgPower))
      .attr("height", d => height-40 - y(d.AvgPower))
      .attr("width", x.bandwidth())
      .attr("fill", "orange");
});
