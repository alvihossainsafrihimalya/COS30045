d3.csv("data/cleandata.csv").then(data => {
  const grouped = d3.rollup(
    data,
    v => d3.sum(v, d => +d["Avg_mode_power"]),
    d => d["Screen_Tech"]
  );

  const processed = Array.from(grouped, ([Screen_Tech, TotalPower]) => ({ Screen_Tech, TotalPower }));

  const width = 400, height = 400, radius = 150;
  const svg = d3.select("#donut").append("svg").attr("viewBox", `0 0 ${width} ${height}`)
                .append("g").attr("transform", `translate(${width/2},${height/2})`);

  const color = d3.scaleOrdinal(d3.schemeCategory10);
  const pie = d3.pie().value(d => d.TotalPower);
  const arcs = pie(processed);
  const arc = d3.arc().innerRadius(70).outerRadius(radius);

  svg.selectAll("path")
    .data(arcs)
    .join("path")
      .attr("d", arc)
      .attr("fill", d => color(d.data.Screen_Tech))
      .attr("stroke", "white")
      .style("stroke-width", "2px");
});
