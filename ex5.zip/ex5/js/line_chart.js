d3.csv("data/cleandata.csv").then(data => {
  data.forEach(d => {
    d["Screen_Size_Inches"] = +d["Screen_Size_Inches"];
    d["Avg_mode_power"] = +d["Avg_mode_power"];
  });

  const sorted = data.sort((a, b) => a["Screen_Size_Inches"] - b["Screen_Size_Inches"]);

  const width = 600, height = 400;
  const svg = d3.select("#line").append("svg").attr("viewBox", `0 0 ${width} ${height}`);

  const x = d3.scaleLinear()
    .domain(d3.extent(sorted, d => d["Screen_Size_Inches"]))
    .range([40, width - 20]);

  const y = d3.scaleLinear()
    .domain([0, d3.max(sorted, d => d["Avg_mode_power"])])
    .range([height - 40, 20]);

  svg.append("g")
    .attr("transform", `translate(0,${height-40})`)
    .call(d3.axisBottom(x));

  svg.append("g")
    .attr("transform", `translate(40,0)`)
    .call(d3.axisLeft(y));

  const line = d3.line()
    .x(d => x(d["Screen_Size_Inches"]))
    .y(d => y(d["Avg_mode_power"]));

  svg.append("path")
    .datum(sorted)
    .attr("d", line)
    .attr("fill", "none")
    .attr("stroke", "blue")
    .attr("stroke-width", 2);
});
