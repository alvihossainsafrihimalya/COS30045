# 📊 TV Energy Consumption Data Visualisation

This website presents visual insights into television energy consumption in the Australian market. It is part of Exercise 3 for the COS30045 – Data Visualisation unit at Swinburne University of Technology.

## 🧑‍🤝‍🧑 Audience
This website is designed for everyday Australian consumers who want to make energy-efficient choices when purchasing televisions. The visualisations aim to simplify complex data into accessible insights.

## 🎯 Purpose
The purpose of this project is to demonstrate the power of data visualisation and storytelling using real-world data. It helps communicate trends in screen technology, power usage, and energy efficiency using visuals generated in KNIME.

## 📁 Pages Overview

- **Home (`index.html`)**: Introduction, project goals, audience, data source, and KNIME workflow.
- **Televisions (`televisions.html`)**: Contains 7 question-answer pairs, each with a chart and result interpretation.
- **About Us (`about.html`)**: Includes credits, context, and declaration of GenAI usage.

## 📊 About the Data

- **Source**: Australian appliance energy ratings (provided dataset)
- **Processing**: Cleaned in KNIME using filtering, GroupBy, Math Formula, and scatter/bar chart nodes.
- **Privacy**: No personal or sensitive data is used.
- **Accuracy**: Based on supplied real-world energy efficiency data.
- **Ethics**: Charts are designed to be truthful and follow visual integrity principles (e.g., Tufte guidelines).

## 🤖 GenAI Declaration

GenAI tools (ChatGPT) were used for:

- Writing descriptions and interpreting charts
- Formatting and structuring HTML and CSS
- Ensuring accessibility and readability
- Writing this README file

All generated content was reviewed, tested, and understood by the student before submission.

## 👨‍🎓 Student Details

- **Name**: Alvi Hossain Safri Himalya  
- **Student ID**: 104223717  
- **Unit**: COS30045 - Data Visualisation (Semester 1, 2025)

