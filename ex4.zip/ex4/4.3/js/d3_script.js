// Select the div and create an SVG inside it
const svg = d3.select("#d3-bar-chart")
  .append("svg")
  .attr("width", 700)
  .attr("height", 450)
  .style("border", "1px solid black");

// Load the cleaned CSV file
d3.csv("data/cleandata.csv").then(data => {
  console.log("Loaded Data Sample:", data.slice(0, 5)); // Optional for debugging

  // Group and count TVs by Screen_Tech
  const screenCounts = d3.rollup(
    data,
    v => v.length,
    d => d["Screen_Tech"] // IMPORTANT: must match your CSV column name exactly
  );

  // Convert rollup map into an array of objects
  const screenData = Array.from(screenCounts, ([screen, count]) => ({ screen, count }));

  // Setup X and Y scales
  const xScale = d3.scaleBand()
    .domain(screenData.map(d => d.screen))
    .range([50, 650]) // Margin added
    .padding(0.2);

  const yScale = d3.scaleLinear()
    .domain([0, d3.max(screenData, d => d.count)])
    .range([400, 50]); // Reversed for SVG (0 at top)

  // Draw bars
  svg.selectAll("rect")
    .data(screenData)
    .join("rect")
    .attr("x", d => xScale(d.screen))
    .attr("y", d => yScale(d.count))
    .attr("width", xScale.bandwidth())
    .attr("height", d => 400 - yScale(d.count))
    .attr("fill", "steelblue");

  // Add count labels on top of bars
  svg.selectAll("text.count")
    .data(screenData)
    .join("text")
    .attr("class", "count")
    .attr("x", d => xScale(d.screen) + xScale.bandwidth() / 2)
    .attr("y", d => yScale(d.count) - 8)
    .attr("text-anchor", "middle")
    .attr("font-size", "12px")
    .attr("fill", "black")
    .text(d => d.count);

  // Add X-axis screen tech names below
  svg.selectAll("text.screen")
    .data(screenData)
    .join("text")
    .attr("class", "screen")
    .attr("x", d => xScale(d.screen) + xScale.bandwidth() / 2)
    .attr("y", 420)
    .attr("text-anchor", "middle")
    .attr("font-size", "12px")
    .attr("fill", "black")
    .text(d => d.screen);

  // OPTIONAL: Add Y-axis lines for better readability
  svg.append("g")
    .attr("transform", "translate(50,0)")
    .call(d3.axisLeft(yScale));

});
