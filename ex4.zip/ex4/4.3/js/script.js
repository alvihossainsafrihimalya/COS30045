
// Power logo click returns to home
document.getElementById("logo").addEventListener("click", function () {
    window.location.href = "index.html";
});

// current active page link
document.addEventListener("DOMContentLoaded", function () {
    const links = document.querySelectorAll("nav a");
    const currentPage = window.location.pathname.split("/").pop();

    links.forEach(link => {
        if (link.getAttribute("href") === currentPage) {
            link.classList.add("active");
        } else {
            link.classList.remove("active");
        }
    });
});
