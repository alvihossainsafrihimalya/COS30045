
d3.csv("data/cleandata.csv").then(function(data) {
  // Populate dropdown with screen types
  const screenTypes = Array.from(new Set(data.map(d => d.Screen_Tech)));
  const dropdown = d3.select("#screenFilter");
  screenTypes.forEach(type => {
    dropdown.append("option").text(type).attr("value", type);
  });

  drawChart("All");

  // Listen for dropdown changes
  dropdown.on("change", function () {
    let selected = this.value;
    drawChart(selected);
  });

  function drawChart(screenType) {
    const filtered = screenType === "All" ? data : data.filter(d => d.Screen_Tech === screenType);

    const counts = d3.rollups(filtered, v => v.length, d => d.Screen_Tech)
      .map(([screen, count]) => ({ screen, count }));

    // Clear previous chart
    d3.select("#barChart").html("");

    const width = 500, height = 300;
    const margin = { top: 20, right: 20, bottom: 40, left: 50 };

    const svg = d3.select("#barChart")
      .append("svg")
      .attr("width", width)
      .attr("height", height)
      .style("background", "#1e1e1e");

    const x = d3.scaleBand()
      .domain(counts.map(d => d.screen))
      .range([margin.left, width - margin.right])
      .padding(0.2);

    const y = d3.scaleLinear()
      .domain([0, d3.max(counts, d => d.count)])
      .nice()
      .range([height - margin.bottom, margin.top]);

    svg.selectAll("rect")
      .data(counts)
      .enter()
      .append("rect")
      .attr("x", d => x(d.screen))
      .attr("y", d => y(d.count))
      .attr("width", x.bandwidth())
      .attr("height", d => height - margin.bottom - y(d.count))
      .attr("fill", "teal");

    svg.selectAll("text.label")
      .data(counts)
      .enter()
      .append("text")
      .attr("x", d => x(d.screen) + x.bandwidth() / 2)
      .attr("y", d => y(d.count) - 5)
      .attr("text-anchor", "middle")
      .attr("fill", "white")
      .text(d => d.count);

    svg.append("g")
      .attr("transform", `translate(0,${height - margin.bottom})`)
      .call(d3.axisBottom(x).tickSizeOuter(0))
      .attr("color", "white");

    svg.append("g")
      .attr("transform", `translate(${margin.left},0)`)
      .call(d3.axisLeft(y))
      .attr("color", "white");
  }
});
