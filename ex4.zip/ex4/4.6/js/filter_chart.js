d3.csv("data/cleandata.csv").then(function(data) {
  // Initial draw
  drawChart("All");

  // Listen for dropdown changes
  d3.select("#screenType").on("change", function () {
    let selected = d3.select(this).property("value");
    drawChart(selected);
  });

  function drawChart(screenType) {
    let filtered = screenType === "All" ? data : data.filter(d => d.Screen_Tech === screenType);

    let counts = d3.rollups(filtered, v => v.length, d => d.Screen_Tech)
      .map(([key, value]) => ({ screen: key, count: value }));

    d3.select("#filter-chart").html(""); // Clear previous chart

    const width = 500;
    const height = 300;

    const svg = d3.select("#filter-chart")
      .append("svg")
      .attr("width", width)
      .attr("height", height)
      .style("border", "1px solid gray");

    const x = d3.scaleBand()
      .domain(counts.map(d => d.screen))
      .range([50, width - 50])
      .padding(0.2);

    const y = d3.scaleLinear()
      .domain([0, d3.max(counts, d => d.count)])
      .range([height - 50, 30]);

    svg.selectAll("rect")
      .data(counts)
      .enter()
      .append("rect")
      .attr("x", d => x(d.screen))
      .attr("y", d => y(d.count))
      .attr("width", x.bandwidth())
      .attr("height", d => height - 50 - y(d.count))
      .attr("fill", "teal");

    svg.selectAll("text.label")
      .data(counts)
      .enter()
      .append("text")
      .attr("class", "label")
      .attr("x", d => x(d.screen) + x.bandwidth() / 2)
      .attr("y", d => y(d.count) - 5)
      .attr("text-anchor", "middle")
      .text(d => d.count);

    // Axes
    svg.append("g")
      .attr("transform", `translate(0,${height - 50})`)
      .call(d3.axisBottom(x));

    svg.append("g")
      .attr("transform", `translate(50,0)`)
      .call(d3.axisLeft(y));
  }
});
